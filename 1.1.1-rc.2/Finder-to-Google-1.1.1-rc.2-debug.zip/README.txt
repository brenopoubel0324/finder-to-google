Migração debug para release — 1.1.1-rc.2/code 9
1. Instale primeiro o novo DEBUG por cima do debug existente. Não desinstale antes de exportar.
2. Configurações > Backup e migração > Exportar configurações. Salve fora da pasta privada do app. Aguarde Backup salvo e verificado. Confira o arquivo no gerenciador.
3. Opcional: Importar configurações > selecionar JSON > conferir resumo > Cancelar, para verificar sem alterar.
4. Somente com o JSON guardado/verificado: desinstale debug, instale RELEASE, importe o JSON e confirme. Conceda novamente o papel padrão no Android.
Não inclui autorização Android, último diagnóstico, pesquisas, URLs, sessão de calibração nem chave de assinatura. O backup da chave no Drive é outro arquivo.
Debug atualiza debug e release atualiza release; assinaturas não se substituem. Leia MIGRACAO_DEBUG_RELEASE.md.
Testes: 124 aprovados no harness; instalação física entre assinaturas no S25 ainda não foi executada neste ambiente.
