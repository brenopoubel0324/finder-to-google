Candidato de otimização 1.1.1-rc.1, code 8 — debug.
Este APK mantém verificações ao abrir links e não acrescenta serviço ou polling.
Atualiza somente instalação com o mesmo certificado. Debug atualiza debug; release atualiza release. Não desinstale para comparar: preserve configurações.
Baseline para release: 1.1.0/code 7; para debug já instalado, pode usar rc.5/code 6 e registrar essa diferença. Não há garantia de downgrade por instalação normal.
Testes no harness: 115 aprovados. Economia de bateria no Samsung ainda não foi medida.
Siga COMPARACAO_NO_APARELHO.md e registre os resultados antes/depois no mesmo aparelho.
SHA256: c1f237c2fa8368e3e22ad9e9a11be94b8f23dc3cd5a6b7a6fdfa2bd398f008d4
Certificado SHA256: dabc6d27ddf900e0f8a137e17aa38ab4e1d4f9ef8500d11186d3c97c77d35823
