Candidato de otimização 1.1.1-rc.1, code 8 — release.
Este APK mantém verificações ao abrir links e não acrescenta serviço ou polling.
Atualiza somente instalação com o mesmo certificado. Debug atualiza debug; release atualiza release. Não desinstale para comparar: preserve configurações.
Baseline para release: 1.1.0/code 7; para debug já instalado, pode usar rc.5/code 6 e registrar essa diferença. Não há garantia de downgrade por instalação normal.
Testes no harness: 115 aprovados. Economia de bateria no Samsung ainda não foi medida.
Siga COMPARACAO_NO_APARELHO.md e registre os resultados antes/depois no mesmo aparelho.
SHA256: 22ad9f0cb6038f2f3ab1dde5b578821f62f67d897ce70ebe5c1a5defecc8ece3
Certificado SHA256: a99bd676fb3a8603605fd94e2fd0cbc7cf36f9d313623931635fa4e1780741c8
